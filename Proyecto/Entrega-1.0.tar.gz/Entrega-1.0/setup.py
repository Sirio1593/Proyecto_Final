from setuptools import setup

setup(

    name= "Entrega",
    version = "1.0",
    description = "Segunda Entrega : paquetes redistribuibles",
    author = "Mariano Sirio",
    author_email = "mariano@uoopaa.com",

    packages = ["Entrega"]

)